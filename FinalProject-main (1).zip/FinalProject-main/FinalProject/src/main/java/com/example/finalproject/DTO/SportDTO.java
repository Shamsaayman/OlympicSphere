package com.example.finalproject.DTO;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
@AllArgsConstructor
public class SportDTO {


    private Integer sport_admin_admin_id;
//    @NotEmpty
    private String name;

}
