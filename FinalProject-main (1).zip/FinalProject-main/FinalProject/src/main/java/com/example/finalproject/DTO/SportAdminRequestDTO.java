package com.example.finalproject.DTO;


import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
@AllArgsConstructor
public class SportAdminRequestDTO {



    private Integer team_admin_team_id ;


    private String status ;


}
