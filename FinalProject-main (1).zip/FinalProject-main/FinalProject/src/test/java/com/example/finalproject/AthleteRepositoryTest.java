package com.example.finalproject;


import com.example.finalproject.API.ApiResponse;
import com.example.finalproject.DTO.AthleteDTO;
import com.example.finalproject.Model.Athlete;
import com.example.finalproject.Model.User;
import com.example.finalproject.Repository.AthleteRepository;
import com.example.finalproject.Service.AthleteService;
import org.assertj.core.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.jdbc.AutoConfigureTestDatabase;
import org.springframework.boot.test.autoconfigure.orm.jpa.DataJpaTest;
import org.springframework.test.context.junit.jupiter.SpringExtension;

import java.util.List;

import static org.hibernate.validator.internal.util.Contracts.assertTrue;
import static org.junit.jupiter.api.Assertions.assertEquals;


@ExtendWith(SpringExtension.class)
@DataJpaTest
@AutoConfigureTestDatabase(replace = AutoConfigureTestDatabase.Replace.NONE)
public class AthleteRepositoryTest {


    @Autowired
    AthleteRepository athleteRepository;
    AthleteService athleteService ;



    User user1 , user2 , user3 ; ;
    AthleteDTO athlete1 , athlete2 , athlete3 ;
    List<Athlete> athleteList1 ;
    Athlete setAthlete1 , setAthlete2 , setAthlete3 ;
    Athlete athlete ;



    @BeforeEach
    void setUp(){
        athlete1 = new AthleteDTO(1 , "naif" , "naif" , "123" , "naif@gmail.com", 23 , 67 , 180 , "Male","Football" , "Professional" , 3 , 1123 , 12345 , 3);
        athlete2 = new AthleteDTO(2 , "mohammad" , "mohammad" , "1234" , "mohammad@gmail.com", 30 , 80 , 189 , "Male","Football" , "Professional" , 2 , 123456 , 125 , 2);
        athlete3 = new AthleteDTO(3 , "saud" , "saud" , "12345" , "saud@gmail.com", 22 , 66 , 179 , "Male","Football" , "Professional" , 1 , 16 , 15 , 1);


        setAthlete1 = new Athlete(athlete1.getId() , athlete1.getUsername() , athlete1.getName() , athlete1.getPassword() , athlete1.getEmail(), athlete1.getAge(), athlete1.getWeight() , athlete1.getHeight() , athlete1.getGender(),athlete1.getSport() , athlete1.getCategory() , athlete1.getAchievements() , athlete1.getIdNumber() , athlete1.getLicenseNumber() , athlete1.getRank() , null , null , null );
        setAthlete2 = new Athlete(athlete2.getId() , athlete2.getUsername() , athlete2.getName() , athlete2.getPassword() , athlete2.getEmail(), athlete2.getAge(), athlete2.getWeight() , athlete2.getHeight() , athlete2.getGender(),athlete2.getSport() , athlete2.getCategory() , athlete2.getAchievements() , athlete2.getIdNumber() , athlete2.getLicenseNumber() , athlete2.getRank() , null , null , null );
        setAthlete3 = new Athlete(athlete3.getId() , athlete3.getUsername() , athlete3.getName() , athlete3.getPassword() , athlete3.getEmail(), athlete3.getAge(), athlete3.getWeight() , athlete3.getHeight() , athlete3.getGender(),athlete3.getSport() , athlete3.getCategory() , athlete3.getAchievements() , athlete3.getIdNumber() , athlete3.getLicenseNumber() , athlete3.getRank() , null , null , null );

        user1 = new User(null , null , null , null , null , null , null , setAthlete1);
        user2 = new User(null , null , null , null , null , null , null , setAthlete2);
        user3 = new User(null , null , null , null , null , null , null , setAthlete3);


    }



    @Test
    public void TestFindAthleteByAthleteId(){
        athleteRepository.save(setAthlete1);
        athleteRepository.save(setAthlete2);
        athleteRepository.save(setAthlete3);

        athlete = athleteRepository.findAthleteByAthleteId(setAthlete2.getAthleteId());

    }



    @Test
    public void TestFindAthleteBySport(){
        athleteRepository.save(setAthlete1);
        athleteRepository.save(setAthlete2);
        athleteRepository.save(setAthlete3);

        athleteList1 = athleteRepository.findAthleteBySport("Football");
    }



    @Test
    public void TestFindAthleteByRankBetween(){
        athleteRepository.save(setAthlete1);
        athleteRepository.save(setAthlete2);
        athleteRepository.save(setAthlete3);

        athleteList1 = athleteRepository.findAthleteByRankBetween(1 , 3);
        assertEquals(3, athleteList1.size());
    }



    @Test
    public void TestFindAthleteByIdNumber(){
        athleteRepository.save(setAthlete1);

        athlete = athleteRepository.findAthleteByIdNumber(setAthlete1.getIdNumber());
        assertEquals(1123 , athlete.getIdNumber());
    }



    @Test
    public void TestFindAthleteByName(){
        athleteRepository.save(setAthlete1);
        athlete = athleteRepository.findAthleteByName(setAthlete1.getName());
        assertEquals(1123 , athlete.getIdNumber());

    }





}
