package com.example.finalproject;

import com.example.finalproject.API.ApiResponse;
import com.example.finalproject.DTO.TeamAdminDTO;
import com.example.finalproject.Model.TeamAdmin;
import com.example.finalproject.Model.User;
import com.example.finalproject.Repository.TeamAdminRepository;
import com.example.finalproject.Service.TeamAdminService;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.extension.ExtendWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.jdbc.AutoConfigureTestDatabase;
import org.springframework.boot.test.autoconfigure.orm.jpa.DataJpaTest;
import org.springframework.test.context.junit.jupiter.SpringExtension;

import java.util.ArrayList;
import java.util.List;
@ExtendWith(SpringExtension.class)
@DataJpaTest
@AutoConfigureTestDatabase(replace = AutoConfigureTestDatabase.Replace.NONE)
public class TeamAdminRepositoryTest {
    @Autowired
    TeamAdminRepository teamAdminRepository;
TeamAdminService teamAdminService;

    User user1 , user2 , user3 ;
    TeamAdmin teamAdmin1, teamAdmin2, teamAdmin3 ;
    TeamAdminDTO teamAdminDTO1 , teamAdminDTO2 , teamAdminDTO3 ;
    ApiResponse apiResponse ;
    List<TeamAdmin> teamAdminList ;



    @BeforeEach
    void setUp() {


        teamAdmin1=new TeamAdmin(1,"Alhilal","123","Fahad bin nafel","alhilal@hotmail.com","054637465",5,user1,null,null,null);
        teamAdmin2=new TeamAdmin(2,"Alahli","1234","Fahad","alahli@hotmail.com","0549262774",4,user2,null,null,null);
        teamAdmin3=new TeamAdmin(3,"Alittihad","12345","mohammed","alittihad@hotmail.com","05550309124",4,user3,null,null,null);

        user1 = new User(null , null , null , null , null , null , teamAdmin1 , null);
        user2 = new User(null , null , null , null , null , null , teamAdmin2 , null);
        user3 = new User(null , null , null , null , null , null , teamAdmin3 , null);

        teamAdminList=new ArrayList<>();
        teamAdminList.add(teamAdmin1);
        teamAdminList.add(teamAdmin2);
        teamAdminList.add(teamAdmin3);
    }






}
